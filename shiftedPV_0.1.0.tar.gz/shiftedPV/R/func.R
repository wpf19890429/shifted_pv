

epsest.func <- function(x,u,sigma)
{
  # x is a vector of normal variables
  # u is the mean
  # sigma is the standard deviation
  # the output is the estimated non-null proportion

  z  = (x - u)/sigma
  xi = c(0:100)/100
  tmax=sqrt(log(length(x)))
  tt=seq(0,tmax,0.1)

  epsest=NULL

  for (j in 1:length(tt)) {

    t=tt[j]
    f  = t*xi
    f  = exp(f^2/2)
    w  = (1 - abs(xi))
    co  = 0*xi

    for (i in 1:101) {
      co[i] = mean(cos(t*xi[i]*z));
    }
    epshat = 1 - sum(w*f*co)/sum(w)
    epsest=c(epsest,epshat)
  }
  return(epsest=max(epsest))
}



#adjust c_star in [0,1]
adjust<-function(c, min=1, max=0)
{
  length(c)
  c_min<-(c+min)/2-abs(c-min)/2
  c_min_max<-(c_min+max)/2+abs(c_min-max)/2
  return(c_min_max)
}
#the log-likelihood function
llk<-function(k,pv,pis) {
  sum(log(pis*k/exp(k*pv)+1-pis))
}
#optimization for ks
likelihood<-function(pv,pis) {
  lm1<-optimize(f=llk, interval=c(0,1000), pv=pv, pis=pis, maximum=T)
  lm1$maximum
}


flogit = function(x) log(x/(1-x))
ilogit = function(x) 1/{1+exp(-x)}



