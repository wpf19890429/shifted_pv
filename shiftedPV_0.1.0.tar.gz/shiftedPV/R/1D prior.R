
prior_1D <- function(pii, x0, x1, theta)
{
  x <- (1 - theta) * x0 + theta * x1
  pv <- 2 * pnorm(-abs(x), 0, 1)

  #Iterative optimize parameter k and prior probability pis.hat
  kor <- likelihood(pv, pis)
  pi.hat <- epsest.func(x, 0, 1)  #Calculate the overall sparsity level
  ks <- likelihood(pv, pi.hat)  #Calculate initial k parameters
  kold <- 1e-4
  passcounter = 1
  lambda = 2    #fix lambda for now
  rel_tol = 1e-4#convergence criterion
  while (abs(kold - ks) / kold > rel_tol && passcounter <= 1000) {
    f0 <- 1
    f1 <- ks * exp(-ks * pv)
    # Initial settings for algorithm
    drift <- 1
    beta_hat <- rep(0, m)
    prior_prob <- ilogit(beta_hat)
    objective_old <-
      sum(log(prior_prob * f1 + (1 - prior_prob) * f0), na.rm = TRUE)
    while (drift > rel_tol) {
      # E step
      prior_prob <- ilogit(beta_hat)
      m1 <- prior_prob * f1
      m0 <- (1 - prior_prob) * f0
      post_prob <- m1 / (m1 + m0)

      # M step
      weights <- prior_prob * (1 - prior_prob)
      y <- beta_hat - (prior_prob - post_prob) / weights

      # Solve the 1D FusedLasso problem using the subroutine in glmgen
      fl0 <-
        trendfilter(
          drop(y),
          weights = drop(weights),
          k = 0,
          family = 'gaussian',
          lambda = lambda
        )

      beta_hat <- fl0$beta
      prior_prob <- ilogit(beta_hat)

      objective_new <-
        sum(log(prior_prob * f1 + (1 - prior_prob) * f0), na.rm = TRUE)
      drift <-
        abs(objective_old - objective_new) / (abs(objective_old) + rel_tol)
      objective_old <- objective_new
    }
    kold <- ks
    ks <- likelihood(pv, prior_prob)
    passcounter <- passcounter + 1
  }
  return(kor, prior_prob, ks)
}
