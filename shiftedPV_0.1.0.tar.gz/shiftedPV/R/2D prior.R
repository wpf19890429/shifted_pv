


#Two different signal area shapes
pisA.func<-function(i, j)
{
  if(i>10 && i<=30 && j>10 && j<=30)
  {y <- 0.8}
  else if(i>50 && i<=70 && j>60 && j<=80)
  {y <- 0.8}
  else
  {y<-0.01}
  return(y)
}


pisB.func<-function(i, j)
{
  if(sqrt((i-20)^2+(j-20)^2<=100))
  {y <- 0.8}
  else if(i>50 && i<=65 && j>60 && j<=75)
  {y <- 0.8}
  else
  {y<-0.01}
  return(y)
}

# Methods


prior_2D <- function(pii, x0, x1, theta)
  {
    x.vec<-(1-thetaS.vec)*x0+thetaS.vec*x1
    x<-matrix(x.vec, dims[1], dims[2])
    pv.vec<-2*pnorm(-abs(x.vec), 0, 1)

    #LASS procedure
    kor<-likelihood(pv.vec,pis.vec)
    pi.est<-epsest.func(x.vec,0,1)
    lambda = 0.38  #Fix lambda for now
    rel_tol = 1e-4
    ks<-likelihood(pv.vec, pi.est)
    kold=0
    passcounter=1
    while(abs(ks-kold)>1e-4 && passcounter<=1000) {
      f0 = 1
      f1 = ks*exp(-ks*pv.vec)
      beta_hat = rep(0,m)
      # Initialization
      prior_prob = ilogit(beta_hat)
      old_objective = sum(-log(prior_prob*f1 + (1-prior_prob)*f0))
      travel=1
      converged = FALSE
      times=1
      while(!converged && times<=1000) {
        # E step
        m1 = prior_prob*f1
        m0 = (1-prior_prob)*f0
        post_prob = m1/(m1+m0)

        # M step: one ADMM iteration, analogous to a single Newton iteration
        weights = prior_prob*(1-prior_prob)
        y = beta_hat - (prior_prob - post_prob)/weights
        y = matrix(y,dims[1],dims[2])
        fl0 = fusedLattice(y=y,weights=weights,lambda = lambda,rho = 1,eps=0.01, maxIter=100)
        beta_hat = drop(fl0$beta)
        prior_prob = ilogit(beta_hat)

        # Check relative convergence
        new_objective = sum(-log(prior_prob*f1 + (1-prior_prob)*f0))
        travel = abs(new_objective - old_objective)
        old_objective = new_objective
        converged = {travel/(old_objective + rel_tol) < rel_tol}
        times=times+1
      }
      kold<-ks
      ks<-likelihood(pv.vec, prior_prob)
      passcounter<-passcounter+1
    }
    return(kor, prior_prob, ks)
}

