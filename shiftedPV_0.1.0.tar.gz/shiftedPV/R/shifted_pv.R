shifted.pv<-function(pv, pis, q , ks)
{

  # the input
    # pv: the p-values
    # pis: conditional probabilities
    # q: the FDR level
    # ks: turning parameter
  # the output
    # nr: the number of hypothesis to be rejected
    # th: the shifted p-value threshold
    # de: the decision rule


#### shifted p_value

	m<-length(pv)
	p_shifted<-pv+log((1-pis)/pis)/ks

	ranked_p_shifted<-p_shifted[order(p_shifted)]
	ranking<-order(p_shifted)

	for(j in m:1)
	{
		c_star<-ranked_p_shifted[j]-log((1-pis)/pis)[ranking]/ks
		c_star<-adjust(c_star)
		FDP_value<-sum(c_star*(1-pis[ranking]),na.rm=TRUE)/j
		if(FDP_value<q)
			break
	}

	th<-ranked_p_shifted[j]
  pv.shifted.de<-rep(0, m)
	pv.shifted.de[which(p_shifted<ranked_p_shifted[j])]<-1
	nr<-sum(pv.shifted.de)

	return(list(th=th, nr=nr, de=pv.shifted.de))

}
